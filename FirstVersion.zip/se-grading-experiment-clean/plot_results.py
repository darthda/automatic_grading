from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# CONFIGURATION
# ============================================================

RESULTS_DIR = Path("results")

# Main input file from the 9-run experiment
RAW_FILE = RESULTS_DIR / "raw_results_q2_9runs.csv"

# If the file has a capital Q because of an older test script, this fallback is used.
RAW_FILE_FALLBACK = RESULTS_DIR / "raw_results_Q2_9runs.csv"

# Output folders
FIGURES_DIR = RESULTS_DIR / "figures_q2_9runs"
METRICS_DIR = RESULTS_DIR / "metrics_q2_9runs"

FIGURES_DIR.mkdir(exist_ok=True)
METRICS_DIR.mkdir(exist_ok=True)


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_raw_file() -> Path:
    if RAW_FILE.exists():
        return RAW_FILE
    if RAW_FILE_FALLBACK.exists():
        return RAW_FILE_FALLBACK
    raise FileNotFoundError(
        f"Could not find {RAW_FILE} or {RAW_FILE_FALLBACK}. "
        "Check your results folder and file name."
    )


def save_plot(filename: str) -> None:
    path = FIGURES_DIR / filename
    plt.tight_layout()
    plt.savefig(path, dpi=250)
    print(f"Saved figure: {path}")
    plt.show()


def clean_prompt_name(prompt: str) -> str:
    return (
        prompt
        .replace("P0_neutral", "P0 Neutral")
        .replace("P1_reference_based", "P1 Reference-Based")
        .replace("P2_rubric_based", "P2 Rubric-Based")
    )


def load_raw_data() -> pd.DataFrame:
    raw_file = get_raw_file()
    raw = pd.read_csv(raw_file)

    # Normalize valid column because CSV may store booleans as True/False strings.
    raw["valid"] = raw["valid"].astype(str).str.lower().eq("true")
    raw = raw[raw["valid"]].copy()

    raw["score"] = pd.to_numeric(raw["score"], errors="coerce")
    raw["ground_truth"] = pd.to_numeric(raw["ground_truth"], errors="coerce")
    raw["run"] = pd.to_numeric(raw["run"], errors="coerce")
    raw["point_level"] = pd.to_numeric(raw["point_level"], errors="coerce")

    raw = raw.dropna(subset=["score", "ground_truth", "run"])

    raw["score"] = raw["score"].astype(float)
    raw["ground_truth"] = raw["ground_truth"].astype(float)
    raw["run"] = raw["run"].astype(int)

    print("Loaded raw file:", raw_file)
    print("Number of valid raw rows:", len(raw))
    print("Runs found:", sorted(raw["run"].unique()))
    print("Rows per prompt:")
    print(raw.groupby("prompt").size())
    print()

    return raw


def compute_answer_metrics(raw: pd.DataFrame) -> pd.DataFrame:
    group_cols = [
        "model",
        "prompt",
        "question_id",
        "answer_id",
        "point_level",
        "variant_type",
        "paraphrase_group",
        "ground_truth",
    ]

    metrics = (
        raw
        .groupby(group_cols)
        .agg(
            runs=("score", "count"),
            scores=("score", lambda x: "|".join(str(int(v)) for v in x)),
            median_score=("score", "median"),
            mean_score=("score", "mean"),
            min_score=("score", "min"),
            max_score=("score", "max"),
            score_variance=("score", "var"),
        )
        .reset_index()
    )

    metrics["score_variance"] = metrics["score_variance"].fillna(0.0)
    metrics["score_range"] = metrics["max_score"] - metrics["min_score"]
    metrics["absolute_error"] = (metrics["median_score"] - metrics["ground_truth"]).abs()
    metrics["bias"] = metrics["median_score"] - metrics["ground_truth"]
    metrics["exact_agreement"] = metrics["absolute_error"] == 0
    metrics["within_1_agreement"] = metrics["absolute_error"] <= 1

    # Stability rate: share of repeated runs equal to the median score.
    stability_rows = []

    for _, row in metrics.iterrows():
        subset = raw[
            (raw["prompt"] == row["prompt"])
            & (raw["answer_id"] == row["answer_id"])
        ]

        stability_rate = (subset["score"] == row["median_score"]).mean()

        stability_rows.append({
            "prompt": row["prompt"],
            "answer_id": row["answer_id"],
            "stability_rate": stability_rate,
        })

    stability_df = pd.DataFrame(stability_rows)

    metrics = metrics.merge(
        stability_df,
        on=["prompt", "answer_id"],
        how="left",
    )

    return metrics


def compute_summary_metrics(answer_metrics: pd.DataFrame) -> pd.DataFrame:
    summary = (
        answer_metrics
        .groupby(["model", "prompt"])
        .agg(
            answers=("answer_id", "count"),
            exact_agreement=("exact_agreement", "mean"),
            within_1_agreement=("within_1_agreement", "mean"),
            mae=("absolute_error", "mean"),
            avg_bias=("bias", "mean"),
            avg_range=("score_range", "mean"),
            avg_variance=("score_variance", "mean"),
            avg_stability_rate=("stability_rate", "mean"),
        )
        .reset_index()
    )

    return summary


def compute_paraphrase_metrics(answer_metrics: pd.DataFrame) -> pd.DataFrame:
    paraphrase = (
        answer_metrics
        .groupby(["model", "prompt", "question_id", "paraphrase_group"])
        .agg(
            number_of_variants=("answer_id", "count"),
            median_scores=("median_score", lambda x: "|".join(str(v) for v in x)),
            min_group_score=("median_score", "min"),
            max_group_score=("median_score", "max"),
            ground_truth=("ground_truth", "first"),
        )
        .reset_index()
    )

    paraphrase["paraphrase_deviation"] = (
        paraphrase["max_group_score"] - paraphrase["min_group_score"]
    )

    paraphrase["stable_group"] = paraphrase["paraphrase_deviation"] == 0
    paraphrase["within_1_group"] = paraphrase["paraphrase_deviation"] <= 1

    return paraphrase


def save_metric_files(
    answer_metrics: pd.DataFrame,
    summary_metrics: pd.DataFrame,
    paraphrase_metrics: pd.DataFrame,
) -> None:
    answer_path = METRICS_DIR / "answer_metrics_q2_9runs.csv"
    summary_path = METRICS_DIR / "summary_metrics_q2_9runs.csv"
    paraphrase_path = METRICS_DIR / "paraphrase_metrics_q2_9runs.csv"

    answer_metrics.to_csv(answer_path, index=False)
    summary_metrics.to_csv(summary_path, index=False)
    paraphrase_metrics.to_csv(paraphrase_path, index=False)

    print("Saved metric files:")
    print(answer_path)
    print(summary_path)
    print(paraphrase_path)
    print()


# ============================================================
# PLOTS
# ============================================================

def plot_agreement_and_stability(summary: pd.DataFrame) -> None:
    summary = summary.copy()
    summary["prompt_label"] = summary["prompt"].apply(clean_prompt_name)

    plt.figure(figsize=(11, 6))

    x = list(range(len(summary)))
    width = 0.25

    plt.bar(
        [i - width for i in x],
        summary["exact_agreement"],
        width=width,
        label="Exact Agreement",
    )
    plt.bar(
        x,
        summary["within_1_agreement"],
        width=width,
        label="±1 Agreement",
    )
    plt.bar(
        [i + width for i in x],
        summary["avg_stability_rate"],
        width=width,
        label="Avg. Stability Rate",
    )

    plt.xticks(x, summary["prompt_label"], rotation=15)
    plt.ylim(0, 1.1)
    plt.ylabel("Score")
    plt.title("Agreement and Repeated-Run Stability by Prompt")
    plt.legend()

    for i, value in enumerate(summary["exact_agreement"]):
        plt.text(i - width, value + 0.02, f"{value:.2f}", ha="center")

    for i, value in enumerate(summary["within_1_agreement"]):
        plt.text(i, value + 0.02, f"{value:.2f}", ha="center")

    for i, value in enumerate(summary["avg_stability_rate"]):
        plt.text(i + width, value + 0.02, f"{value:.2f}", ha="center")

    save_plot("01_agreement_stability_by_prompt.png")


def plot_mae(summary: pd.DataFrame) -> None:
    summary = summary.copy()
    summary["prompt_label"] = summary["prompt"].apply(clean_prompt_name)

    plt.figure(figsize=(9, 6))

    bars = plt.bar(summary["prompt_label"], summary["mae"])

    plt.ylabel("Mean Absolute Error")
    plt.title("Mean Absolute Error by Prompt")
    plt.xticks(rotation=15)

    y_max = max(summary["mae"].max() + 0.1, 0.2)
    plt.ylim(0, y_max)

    for bar, value in zip(bars, summary["mae"]):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.01,
            f"{value:.2f}",
            ha="center",
        )

    save_plot("02_mae_by_prompt.png")


def plot_average_range(summary: pd.DataFrame) -> None:
    summary = summary.copy()
    summary["prompt_label"] = summary["prompt"].apply(clean_prompt_name)

    plt.figure(figsize=(9, 6))

    bars = plt.bar(summary["prompt_label"], summary["avg_range"])

    plt.ylabel("Average Score Range")
    plt.title("Repeated-Run Score Range by Prompt")
    plt.xticks(rotation=15)

    y_max = max(summary["avg_range"].max() + 0.1, 0.2)
    plt.ylim(0, y_max)

    for bar, value in zip(bars, summary["avg_range"]):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.01,
            f"{value:.2f}",
            ha="center",
        )

    save_plot("03_avg_score_range_by_prompt.png")


def plot_bias(summary: pd.DataFrame) -> None:
    summary = summary.copy()
    summary["prompt_label"] = summary["prompt"].apply(clean_prompt_name)

    plt.figure(figsize=(9, 6))

    bars = plt.bar(summary["prompt_label"], summary["avg_bias"])

    plt.axhline(0, linestyle="--")
    plt.ylabel("Average Bias")
    plt.title("Average Grading Bias by Prompt")
    plt.xticks(rotation=15)

    for bar, value in zip(bars, summary["avg_bias"]):
        offset = 0.02 if value >= 0 else -0.04
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + offset,
            f"{value:.2f}",
            ha="center",
        )

    save_plot("04_bias_by_prompt.png")


def plot_average_score_over_runs(raw: pd.DataFrame) -> None:
    grouped = (
        raw
        .groupby(["prompt", "run"])
        .agg(mean_score=("score", "mean"))
        .reset_index()
    )

    plt.figure(figsize=(11, 6))

    for prompt, group in grouped.groupby("prompt"):
        plt.plot(
            group["run"],
            group["mean_score"],
            marker="o",
            label=clean_prompt_name(prompt),
        )

    plt.xlabel("Run")
    plt.ylabel("Average Assigned Score")
    plt.title("Average Assigned Score Across Repeated Runs")
    plt.xticks(sorted(raw["run"].unique()))
    plt.legend()

    save_plot("05_average_score_over_runs.png")


def plot_mae_over_runs(raw: pd.DataFrame) -> None:
    data = raw.copy()
    data["absolute_error"] = (data["score"] - data["ground_truth"]).abs()

    grouped = (
        data
        .groupby(["prompt", "run"])
        .agg(mean_absolute_error=("absolute_error", "mean"))
        .reset_index()
    )

    plt.figure(figsize=(11, 6))

    for prompt, group in grouped.groupby("prompt"):
        plt.plot(
            group["run"],
            group["mean_absolute_error"],
            marker="o",
            label=clean_prompt_name(prompt),
        )

    plt.xlabel("Run")
    plt.ylabel("Mean Absolute Error")
    plt.title("Mean Absolute Error Across Repeated Runs")
    plt.xticks(sorted(raw["run"].unique()))
    plt.legend()

    save_plot("06_mae_over_runs.png")


def plot_ground_truth_vs_median(answer_metrics: pd.DataFrame) -> None:
    for prompt, subset in answer_metrics.groupby("prompt"):
        plt.figure(figsize=(7, 7))

        plt.scatter(subset["ground_truth"], subset["median_score"])
        plt.plot([0, 5], [0, 5], linestyle="--")

        plt.xlabel("Ground-Truth Score")
        plt.ylabel("Median Model Score")
        plt.title(f"Ground Truth vs. Median Score: {clean_prompt_name(prompt)}")

        plt.xticks(range(0, 6))
        plt.yticks(range(0, 6))
        plt.xlim(-0.2, 5.2)
        plt.ylim(-0.2, 5.2)

        safe_prompt = prompt.replace("/", "_")
        save_plot(f"07_ground_truth_vs_median_{safe_prompt}.png")


def plot_error_by_point_level(answer_metrics: pd.DataFrame) -> None:
    grouped = (
        answer_metrics
        .groupby(["prompt", "ground_truth"])
        .agg(mean_absolute_error=("absolute_error", "mean"))
        .reset_index()
    )

    plt.figure(figsize=(11, 6))

    for prompt, group in grouped.groupby("prompt"):
        plt.plot(
            group["ground_truth"],
            group["mean_absolute_error"],
            marker="o",
            label=clean_prompt_name(prompt),
        )

    plt.xlabel("Ground-Truth Point Level")
    plt.ylabel("Mean Absolute Error")
    plt.title("Error by Ground-Truth Point Level")
    plt.xticks(range(0, 6))
    plt.legend()

    save_plot("08_error_by_point_level.png")


def plot_paraphrase_deviation(paraphrase: pd.DataFrame) -> None:
    prompts = list(paraphrase["prompt"].unique())
    groups = list(paraphrase["paraphrase_group"].unique())

    x = list(range(len(groups)))
    width = 0.25

    plt.figure(figsize=(13, 6))

    for idx, prompt in enumerate(prompts):
        subset = paraphrase[paraphrase["prompt"] == prompt].set_index("paraphrase_group")

        values = [
            subset.loc[group, "paraphrase_deviation"]
            if group in subset.index
            else 0
            for group in groups
        ]

        offsets = [i + (idx - 1) * width for i in x]

        plt.bar(
            offsets,
            values,
            width=width,
            label=clean_prompt_name(prompt),
        )

    plt.xlabel("Paraphrase Group")
    plt.ylabel("Paraphrase Deviation")
    plt.title("Paraphrase Robustness by Prompt")
    plt.xticks(x, groups, rotation=45)
    plt.legend()

    save_plot("09_paraphrase_deviation_by_group.png")


def plot_stable_paraphrase_groups(paraphrase: pd.DataFrame) -> None:
    grouped = (
        paraphrase
        .groupby("prompt")
        .agg(
            stable_group_rate=("stable_group", "mean"),
            within_1_group_rate=("within_1_group", "mean"),
        )
        .reset_index()
    )

    grouped["prompt_label"] = grouped["prompt"].apply(clean_prompt_name)

    plt.figure(figsize=(10, 6))

    x = list(range(len(grouped)))
    width = 0.35

    plt.bar(
        [i - width / 2 for i in x],
        grouped["stable_group_rate"],
        width=width,
        label="Deviation = 0",
    )
    plt.bar(
        [i + width / 2 for i in x],
        grouped["within_1_group_rate"],
        width=width,
        label="Deviation ≤ 1",
    )

    plt.xticks(x, grouped["prompt_label"], rotation=15)
    plt.ylim(0, 1.1)
    plt.ylabel("Share of Paraphrase Groups")
    plt.title("Stable and Tolerant Paraphrase Robustness by Prompt")
    plt.legend()

    for i, value in enumerate(grouped["stable_group_rate"]):
        plt.text(i - width / 2, value + 0.02, f"{value:.2f}", ha="center")

    for i, value in enumerate(grouped["within_1_group_rate"]):
        plt.text(i + width / 2, value + 0.02, f"{value:.2f}", ha="center")

    save_plot("10_stable_paraphrase_groups_by_prompt.png")


def plot_score_distribution(raw: pd.DataFrame) -> None:
    grouped = (
        raw
        .groupby(["prompt", "score"])
        .size()
        .reset_index(name="count")
    )

    for prompt, subset in grouped.groupby("prompt"):
        plt.figure(figsize=(8, 6))

        plt.bar(subset["score"], subset["count"])

        plt.xlabel("Assigned Score")
        plt.ylabel("Count")
        plt.title(f"Score Distribution: {clean_prompt_name(prompt)}")
        plt.xticks(range(0, 6))

        safe_prompt = prompt.replace("/", "_")
        save_plot(f"11_score_distribution_{safe_prompt}.png")


def plot_score_distribution_combined(raw: pd.DataFrame) -> None:
    grouped = (
        raw
        .groupby(["prompt", "score"])
        .size()
        .reset_index(name="count")
    )

    prompts = list(raw["prompt"].unique())
    scores = list(range(0, 6))
    x = list(range(len(scores)))
    width = 0.25

    plt.figure(figsize=(11, 6))

    for idx, prompt in enumerate(prompts):
        subset = grouped[grouped["prompt"] == prompt].set_index("score")

        values = [
            subset.loc[score, "count"] if score in subset.index else 0
            for score in scores
        ]

        offsets = [i + (idx - 1) * width for i in x]

        plt.bar(
            offsets,
            values,
            width=width,
            label=clean_prompt_name(prompt),
        )

    plt.xlabel("Assigned Score")
    plt.ylabel("Count")
    plt.title("Score Distribution by Prompt")
    plt.xticks(x, scores)
    plt.legend()

    save_plot("12_score_distribution_combined.png")


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    raw = load_raw_data()

    answer_metrics = compute_answer_metrics(raw)
    summary_metrics = compute_summary_metrics(answer_metrics)
    paraphrase_metrics = compute_paraphrase_metrics(answer_metrics)

    save_metric_files(answer_metrics, summary_metrics, paraphrase_metrics)

    print("Summary metrics:")
    print(summary_metrics)
    print()

    print("Paraphrase metrics:")
    print(paraphrase_metrics)
    print()

    plot_agreement_and_stability(summary_metrics)
    plot_mae(summary_metrics)
    plot_average_range(summary_metrics)
    plot_bias(summary_metrics)
    plot_average_score_over_runs(raw)
    plot_mae_over_runs(raw)
    plot_ground_truth_vs_median(answer_metrics)
    plot_error_by_point_level(answer_metrics)
    plot_paraphrase_deviation(paraphrase_metrics)
    plot_stable_paraphrase_groups(paraphrase_metrics)
    plot_score_distribution(raw)
    plot_score_distribution_combined(raw)

    print()
    print("Done.")
    print(f"Figures saved in: {FIGURES_DIR}")
    print(f"Metrics saved in: {METRICS_DIR}")


if __name__ == "__main__":
    main()