import os
from dotenv import load_dotenv
from google import genai


def main():
    load_dotenv()

    api_key = os.getenv("GOOGLE_API_KEY")
    model = os.getenv("GEMINI_MODEL")

    if not api_key:
        raise RuntimeError("GOOGLE_API_KEY is missing in .env")

    if not model:
        raise RuntimeError("GEMINI_MODEL is missing in .env")

    client = genai.Client(api_key=api_key)

    prompt = """
Return only valid JSON.
Do not include explanations.

Question:
What is 2 + 2?

Return the result in this format:

{
  "score": 4
}
"""

    response = client.models.generate_content(
        model=model,
        contents=prompt,
    )

    print("Model:", model)
    print("Response:")
    print(response.text)


if __name__ == "__main__":
    main()