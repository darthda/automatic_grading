from pathlib import Path
import csv


DATA_DIR = Path("data")
PROMPT_DIR = Path("prompts")


def read_first_row(csv_path):
    with open(csv_path, "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)
        return next(reader)


def read_prompt_template(path):
    with open(path, "r", encoding="utf-8") as file:
        return file.read()


def main():
    question = read_first_row(DATA_DIR / "questions.csv")

    # Pick one answer for preview.
    # You can change this later, e.g. to Q2_5_V1.
    selected_answer_id = "Q2_4_V1"

    selected_answer = None
    with open(DATA_DIR / "answers.csv", "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if row["answer_id"] == selected_answer_id:
                selected_answer = row
                break

    if selected_answer is None:
        raise ValueError(f"Answer ID not found: {selected_answer_id}")

    prompt_files = [
        "p0_neutral.txt",
        "p1_reference_based.txt",
        "p2_rubric_based.txt",
    ]

    for prompt_file in prompt_files:
        template = read_prompt_template(PROMPT_DIR / prompt_file)

        filled_prompt = template.format(
            question=question["question"],
            reference_answer=question["reference_answer"],
            rubric=question["rubric"],
            student_answer=selected_answer["student_answer"],
            max_score=question["max_score"],
        )

        print("\n" + "=" * 80)
        print(f"PROMPT FILE: {prompt_file}")
        print(f"ANSWER ID: {selected_answer_id}")
        print(f"GROUND TRUTH: {selected_answer['ground_truth']}")
        print("=" * 80)
        print(filled_prompt)


if __name__ == "__main__":
    main()