from pathlib import Path
import csv


DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)


question = {
    "question_id": "Q2",
    "topic": "Requirements Engineering",
    "question": "Explain the difference between functional and non-functional requirements and give one example for each.",
    "reference_answer": (
        "Functional requirements describe what a system should do, such as allowing a user "
        "to reserve a bike in a rental app. Non-functional requirements describe qualities "
        "or constraints of the system, such as performance, security, usability, or reliability. "
        "The main difference is that functional requirements define system behavior or features, "
        "whereas non-functional requirements define how well the system should operate or which "
        "quality constraints it must satisfy."
    ),
    "max_score": 5,
    "rubric": (
        "1 point: Correctly defines functional requirements as system behavior, features, or functions. "
        "1 point: Gives a valid example of a functional requirement. "
        "1 point: Correctly defines non-functional requirements as quality attributes, constraints, or properties. "
        "1 point: Gives a valid example of a non-functional requirement. "
        "1 point: Clearly explains the difference between functional and non-functional requirements."
    )
}


answers = [
    # 0 points
    {
        "answer_id": "Q2_0_V1",
        "question_id": "Q2",
        "point_level": 0,
        "variant_type": "original",
        "paraphrase_group": "Q2_0",
        "ground_truth": 0,
        "student_answer": (
            "Functional requirements are written by programmers and non-functional requirements "
            "are written by customers. They are basically documents used before coding starts."
        ),
    },
    {
        "answer_id": "Q2_0_V2",
        "question_id": "Q2",
        "point_level": 0,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_0",
        "ground_truth": 0,
        "student_answer": (
            "The difference is mainly who writes them: developers write functional requirements, "
            "while users write non-functional requirements. Both are just planning notes."
        ),
    },
    {
        "answer_id": "Q2_0_V3",
        "question_id": "Q2",
        "point_level": 0,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_0",
        "ground_truth": 0,
        "student_answer": (
            "They are both project documents. Non-functional requirements come from users, "
            "functional requirements come from developers, so there is no technical difference."
        ),
    },

    # 1 point
    {
        "answer_id": "Q2_1_V1",
        "question_id": "Q2",
        "point_level": 1,
        "variant_type": "original",
        "paraphrase_group": "Q2_1",
        "ground_truth": 1,
        "student_answer": "Functional requirements describe what features a system should provide.",
    },
    {
        "answer_id": "Q2_1_V2",
        "question_id": "Q2",
        "point_level": 1,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_1",
        "ground_truth": 1,
        "student_answer": "A functional requirement says which function or behavior the software must have.",
    },
    {
        "answer_id": "Q2_1_V3",
        "question_id": "Q2",
        "point_level": 1,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_1",
        "ground_truth": 1,
        "student_answer": "It is about system functionality, meaning the things the application should do.",
    },

    # 2 points
    {
        "answer_id": "Q2_2_V1",
        "question_id": "Q2",
        "point_level": 2,
        "variant_type": "original",
        "paraphrase_group": "Q2_2",
        "ground_truth": 2,
        "student_answer": (
            "Functional requirements describe what the system should do, for example allowing "
            "a user to reserve a bike."
        ),
    },
    {
        "answer_id": "Q2_2_V2",
        "question_id": "Q2",
        "point_level": 2,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_2",
        "ground_truth": 2,
        "student_answer": (
            "A functional requirement specifies a feature of the software. One example would be "
            "that customers can create a reservation in the app."
        ),
    },
    {
        "answer_id": "Q2_2_V3",
        "question_id": "Q2",
        "point_level": 2,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_2",
        "ground_truth": 2,
        "student_answer": (
            "Example: the app lets users reserve bikes. This is functional because it describes "
            "a concrete behavior of the system."
        ),
    },

    # 3 points
    {
        "answer_id": "Q2_3_V1",
        "question_id": "Q2",
        "point_level": 3,
        "variant_type": "original",
        "paraphrase_group": "Q2_3",
        "ground_truth": 3,
        "student_answer": (
            "Functional requirements describe what the system should do. Non-functional "
            "requirements describe quality constraints. The difference is that one is about "
            "functionality and the other is about system qualities."
        ),
    },
    {
        "answer_id": "Q2_3_V2",
        "question_id": "Q2",
        "point_level": 3,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_3",
        "ground_truth": 3,
        "student_answer": (
            "Functional requirements define the functions or behavior of a system, while "
            "non-functional requirements define qualities or constraints. In other words, "
            "they separate what the system does from quality-related expectations."
        ),
    },
    {
        "answer_id": "Q2_3_V3",
        "question_id": "Q2",
        "point_level": 3,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_3",
        "ground_truth": 3,
        "student_answer": (
            "The difference is functionality versus quality. Functional requirements define "
            "system behavior; non-functional requirements define constraints or quality aspects."
        ),
    },

    # 4 points
    {
        "answer_id": "Q2_4_V1",
        "question_id": "Q2",
        "point_level": 4,
        "variant_type": "original",
        "paraphrase_group": "Q2_4",
        "ground_truth": 4,
        "student_answer": (
            "Functional requirements describe what the system should do, for example allowing "
            "users to reserve a bike. Non-functional requirements describe quality constraints, "
            "for example performance or security."
        ),
    },
    {
        "answer_id": "Q2_4_V2",
        "question_id": "Q2",
        "point_level": 4,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_4",
        "ground_truth": 4,
        "student_answer": (
            "A functional requirement specifies a feature, such as creating a bike reservation. "
            "A non-functional requirement specifies a quality property, such as response time "
            "or data protection."
        ),
    },
    {
        "answer_id": "Q2_4_V3",
        "question_id": "Q2",
        "point_level": 4,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_4",
        "ground_truth": 4,
        "student_answer": (
            "Example of a functional requirement: users can reserve bikes. Example of a "
            "non-functional requirement: the app should be fast or secure. Functional "
            "requirements describe system functions, while non-functional ones describe qualities."
        ),
    },

    # 5 points
    {
        "answer_id": "Q2_5_V1",
        "question_id": "Q2",
        "point_level": 5,
        "variant_type": "original",
        "paraphrase_group": "Q2_5",
        "ground_truth": 5,
        "student_answer": (
            "Functional requirements describe what a system should do, such as allowing a user "
            "to reserve a bike in a rental app. Non-functional requirements describe qualities "
            "or constraints of the system, such as performance, security, or usability. The main "
            "difference is that functional requirements define system behavior, while non-functional "
            "requirements define how well the system should operate."
        ),
    },
    {
        "answer_id": "Q2_5_V2",
        "question_id": "Q2",
        "point_level": 5,
        "variant_type": "paraphrase",
        "paraphrase_group": "Q2_5",
        "ground_truth": 5,
        "student_answer": (
            "A functional requirement specifies a concrete feature or action the software must "
            "provide, for example that customers can reserve bicycles. A non-functional requirement "
            "specifies a quality constraint, for example that the reservation page must load quickly "
            "or that user data must be protected. Thus, functional requirements describe behavior, "
            "whereas non-functional requirements describe quality expectations."
        ),
    },
    {
        "answer_id": "Q2_5_V3",
        "question_id": "Q2",
        "point_level": 5,
        "variant_type": "reordered_condensed",
        "paraphrase_group": "Q2_5",
        "ground_truth": 5,
        "student_answer": (
            "The key distinction is between what the system does and how well it does it. "
            "Functional requirements define behavior or features, such as reserving a bike. "
            "Non-functional requirements define quality constraints, such as security, usability, "
            "or response time."
        ),
    },
]


def write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


write_csv(
    DATA_DIR / "questions.csv",
    [question],
    ["question_id", "topic", "question", "reference_answer", "max_score", "rubric"],
)

write_csv(
    DATA_DIR / "answers.csv",
    answers,
    [
        "answer_id",
        "question_id",
        "point_level",
        "variant_type",
        "paraphrase_group",
        "ground_truth",
        "student_answer",
    ],
)

print("Dataset created successfully.")
print("Created file: data/questions.csv")
print("Created file: data/answers.csv")
print(f"Number of questions: 1")
print(f"Number of answers: {len(answers)}")