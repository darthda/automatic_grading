import os
import csv
import json
import re
import time
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from google.genai import types

# Change this for each daily run, e.g. Q2, Q1, Q3.
TARGET_QUESTION_ID = "Q2"

RUNS_PER_ANSWER = 9
MAX_REQUESTS_THIS_EXECUTION = 486
SLEEP_SECONDS = 5

DATA_DIR = Path("data")
PROMPT_DIR = Path("prompts")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

PROMPT_FILES = {
    "P0_neutral": "p0_neutral.txt",
    "P1_reference_based": "p1_reference_based.txt",
    "P2_rubric_based": "p2_rubric_based.txt",
}

RESULT_FILE = RESULTS_DIR / f"raw_results_{TARGET_QUESTION_ID.lower()}_9runs.csv"


def read_csv(path: Path):
    with open(path, "r", encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def read_prompt_template(path: Path):
    with open(path, "r", encoding="utf-8") as file:
        return file.read()


def extract_score(response_text: str, max_score: int) -> int:
    text = response_text.strip()
    try:
        data = json.loads(text)
        score = int(data["score"])
    except Exception:
        match = re.search(r'"score"\s*:\s*(\d+)', text, re.IGNORECASE)
        if not match:
            match = re.search(r'\b([0-5])\b', text)
        if not match:
            raise ValueError(f"Could not extract score from response: {text}")
        score = int(match.group(1))
    if score < 0 or score > int(max_score):
        raise ValueError(f"Score {score} outside allowed range 0-{max_score}")
    return score


def load_existing_keys(result_path: Path):
    existing = set()
    if not result_path.exists():
        return existing
    with open(result_path, "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            existing.add((row["prompt"], row["answer_id"], row["run"]))
    return existing


def main():
    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY")
    model = os.getenv("GEMINI_MODEL")
    if not api_key:
        raise RuntimeError("GOOGLE_API_KEY is missing in .env")
    if not model:
        raise RuntimeError("GEMINI_MODEL is missing in .env")

    client = genai.Client(api_key=api_key)
    questions = read_csv(DATA_DIR / "questions.csv")
    all_answers = read_csv(DATA_DIR / "answers.csv")
    questions_by_id = {q["question_id"]: q for q in questions}
    if TARGET_QUESTION_ID not in questions_by_id:
        raise RuntimeError(f"Question not found in questions.csv: {TARGET_QUESTION_ID}")

    answers = [a for a in all_answers if a["question_id"] == TARGET_QUESTION_ID]
    if not answers:
        raise RuntimeError(f"No answers found for question: {TARGET_QUESTION_ID}")

    prompt_templates = {
        name: read_prompt_template(PROMPT_DIR / file_name)
        for name, file_name in PROMPT_FILES.items()
    }
    planned = len(answers) * len(prompt_templates) * RUNS_PER_ANSWER
    if planned > MAX_REQUESTS_THIS_EXECUTION:
        raise RuntimeError(f"Planned requests ({planned}) exceed safe limit ({MAX_REQUESTS_THIS_EXECUTION}).")

    print(f"Target question: {TARGET_QUESTION_ID}")
    print(f"Planned requests: {planned}")
    print(f"Result file: {RESULT_FILE}")

    fieldnames = [
        "model", "prompt", "question_id", "answer_id", "point_level",
        "variant_type", "paraphrase_group", "ground_truth", "run", "score",
        "valid", "error", "raw_response",
    ]

    file_exists = RESULT_FILE.exists()
    existing_keys = load_existing_keys(RESULT_FILE)
    request_count = 0

    with open(RESULT_FILE, "a", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()

        for answer in answers:
            question = questions_by_id[answer["question_id"]]
            for prompt_name, template in prompt_templates.items():
                for run in range(1, RUNS_PER_ANSWER + 1):
                    key = (prompt_name, answer["answer_id"], str(run))
                    if key in existing_keys:
                        continue
                    if request_count >= MAX_REQUESTS_THIS_EXECUTION:
                        print("Reached safe execution limit. Stop and continue tomorrow.")
                        return
                    request_count += 1
                    filled_prompt = template.format(
                        question=question["question"],
                        reference_answer=question["reference_answer"],
                        rubric=question["rubric"],
                        student_answer=answer["student_answer"],
                        max_score=question["max_score"],
                    )
                    print(f"[{request_count}/{planned}] {model} | {prompt_name} | {answer['answer_id']} | run {run}")
                    raw_response = ""
                    score = ""
                    valid = True
                    error = ""
                    try:
                        response = client.models.generate_content(
                            model=model,
                            contents=filled_prompt,
                            config=types.GenerateContentConfig(
                                temperature=0,
                                max_output_tokens=50,
                                response_mime_type="application/json",
                            ),
                        )
                        raw_response = response.text
                        score = extract_score(raw_response, int(question["max_score"]))
                    except Exception as exc:
                        valid = False
                        error = str(exc)
                    writer.writerow({
                        "model": model,
                        "prompt": prompt_name,
                        "question_id": answer["question_id"],
                        "answer_id": answer["answer_id"],
                        "point_level": answer["point_level"],
                        "variant_type": answer["variant_type"],
                        "paraphrase_group": answer["paraphrase_group"],
                        "ground_truth": answer["ground_truth"],
                        "run": run,
                        "score": score,
                        "valid": valid,
                        "error": error,
                        "raw_response": raw_response.replace("\n", "\\n"),
                    })
                    file.flush()
                    time.sleep(SLEEP_SECONDS)
    print("Experiment finished.")


if __name__ == "__main__":
    main()
