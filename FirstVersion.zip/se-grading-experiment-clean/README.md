# Prompt-Based Consistent Evaluation of Software Engineering Exam Answers

This repository contains a small benchmark and evaluation pipeline for prompt-based grading of open-text software engineering exam answers.

## Setup

```bash
pip install -r requirements.txt
copy .env.example .env
```

Then add your Google Gemini API key to `.env`.

## Run Q2 experiment

```bash
python run_gemini_question_9runs.py
```

The default target question is `Q2`. The script uses 9 repeated runs, 3 prompt variants, and deterministic Gemini settings.

## Plot results

```bash
python plot_results.py
```

Figures and metric CSV files are written to `results/`.
